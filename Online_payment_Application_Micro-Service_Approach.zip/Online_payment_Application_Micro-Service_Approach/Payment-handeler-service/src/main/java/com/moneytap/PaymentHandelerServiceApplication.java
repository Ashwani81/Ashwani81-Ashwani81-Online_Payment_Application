package com.moneytap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentHandelerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentHandelerServiceApplication.class, args);
	}

}
