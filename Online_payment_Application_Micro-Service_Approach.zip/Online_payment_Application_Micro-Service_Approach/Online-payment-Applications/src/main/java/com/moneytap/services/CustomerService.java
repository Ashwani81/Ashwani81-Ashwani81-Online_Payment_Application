package com.moneytap.services;

import com.moneytap.exceptions.AlreadyCustomerAvailableException;
import com.moneytap.exceptions.WalletIdNotFoundException;
import com.moneytap.modal.Customer;

import java.util.List;

public interface CustomerService {
    void customerRegistration(Customer customer,int walletId) throws WalletIdNotFoundException, AlreadyCustomerAvailableException;
}
