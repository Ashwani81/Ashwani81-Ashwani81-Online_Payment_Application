package com.moneytap.modal;

import java.util.List;

public class BillPaymentList {
    private List<BillPayment> billPaymentList;

    public List<BillPayment> getBillPaymentList() {
        return billPaymentList;
    }

    public void setBillPaymentList(List<BillPayment> billPaymentList) {
        this.billPaymentList = billPaymentList;
    }
}
