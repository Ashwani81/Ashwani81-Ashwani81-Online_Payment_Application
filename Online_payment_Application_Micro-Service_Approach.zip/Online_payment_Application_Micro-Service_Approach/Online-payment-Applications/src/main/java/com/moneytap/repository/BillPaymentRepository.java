package com.moneytap.repository;

import com.moneytap.modal.BillPayment;
import org.springframework.data.repository.CrudRepository;

public interface BillPaymentRepository extends CrudRepository<BillPayment,Integer> {
}
