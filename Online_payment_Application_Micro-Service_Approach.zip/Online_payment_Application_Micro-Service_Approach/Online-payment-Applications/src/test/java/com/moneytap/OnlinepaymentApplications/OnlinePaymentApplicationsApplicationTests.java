package com.moneytap.OnlinepaymentApplications;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinePaymentApplicationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
