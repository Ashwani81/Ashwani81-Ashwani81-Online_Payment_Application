package com.moneytap.BankInfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
