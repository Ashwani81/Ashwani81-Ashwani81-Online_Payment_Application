package com.moneytap.exceptions;

public class BillIdNotFoundException extends Exception{
    public BillIdNotFoundException(String msg){
        super(msg);
    }
}
