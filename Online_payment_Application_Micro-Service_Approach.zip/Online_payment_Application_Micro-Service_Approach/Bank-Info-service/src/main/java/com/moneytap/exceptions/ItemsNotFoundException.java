package com.moneytap.exceptions;

public class ItemsNotFoundException extends Exception{
    public ItemsNotFoundException(String msg){
        super(msg);
    }
}
