package com.moneytap.exceptions;

public class AlreadyCustomerAvailableException extends Exception{
    public AlreadyCustomerAvailableException(String msg){
        super(msg);
    }
}
