package com.moneytap.modal;

import java.util.List;

public class BeneficiaryList {
    private List<BeneficieryDetails> beneficieryDetailsList;

    public List<BeneficieryDetails> getBeneficieryDetailsList() {
        return beneficieryDetailsList;
    }

    public void setBeneficieryDetailsList(List<BeneficieryDetails> beneficieryDetailsList) {
        this.beneficieryDetailsList = beneficieryDetailsList;
    }
}
