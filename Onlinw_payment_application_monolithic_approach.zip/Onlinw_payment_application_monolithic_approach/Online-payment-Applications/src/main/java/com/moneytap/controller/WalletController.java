package com.moneytap.controller;

import com.moneytap.exceptions.*;
import com.moneytap.modal.BillPayment;
import com.moneytap.modal.Customer;
import com.moneytap.modal.Transaction;
import com.moneytap.modal.Wallet;
import com.moneytap.services.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/wallet")
public class WalletController {
    @Autowired
    private WalletService walletService;

    @RequestMapping(method = RequestMethod.POST,value = "/create")
    public void createWallet(@RequestBody Wallet wallet) throws BankAccountNotFoundException {
        walletService.createWallet(wallet);
    }

    @RequestMapping(method = RequestMethod.GET,value = "/{walletId}")
    public double getBalance(@PathVariable int walletId) throws CustomerNotFoundException, WalletIdNotFoundException {
        return walletService.getBalance(walletId);
    }

    @GetMapping("/admin")
    public List<Customer> getCustomer(){
       return walletService.getCustomer();
    }

    @PostMapping("/password/{customerId}/{oldPassword}/{newPassword}/{conformPassword}")
    public  void changePassword(@PathVariable  int customerId,@PathVariable String oldPassword,@PathVariable String newPassword,@PathVariable String conformPassword) throws InvalidUserNameAndPasswordException, CustomerNotFoundException {
        walletService.changePassword(customerId,oldPassword,newPassword,conformPassword);

    }
    @PostMapping("/addAmount/{walletId}/{amount}/{accountNo}")
    public void addMoneyInWallet(@PathVariable int walletId,@PathVariable double amount,@PathVariable int accountNo) throws BankAccountNotFoundException, InsufficientBalanceException, WalletIdNotFoundException {
        walletService.addMoneyInWallet(walletId,amount,accountNo);


    }
    @PostMapping("/fundTransferToBeneficiary/{userWalletId}/{benMobileNo}/{amount}")
   public void fundTransfer(@PathVariable int userWalletId, @PathVariable String benMobileNo, @PathVariable double amount) throws BenefecieryNotFoundException, InsufficientBalanceException, WalletIdNotFoundException {
            walletService.fundTransfer(userWalletId,benMobileNo,amount);
   }
   @PostMapping("/deposit/{walletId}/{amount}/{accountNo}")
    public void depositAmount(@PathVariable int walletId,@PathVariable double amount,@PathVariable int accountNo) throws BankAccountNotFoundException, WalletIdNotFoundException, InsufficientBalanceException {
        walletService.depositAmount(walletId,amount,accountNo);


    }


    @PostMapping("/billPay/{walletId}/{amount}")
    public void billPayment(@PathVariable int walletId,@PathVariable double amount) throws WalletIdNotFoundException, InsufficientBalanceException {
        walletService.billPayment(walletId,amount);
    }


}
