package com.moneytap.exceptions;

public class WalletIdNotFoundException extends Exception{
    public WalletIdNotFoundException(String msg){
        super(msg);
    }
}
