package com.moneytap.controller;

import com.moneytap.exceptions.BenefecieryNotFoundException;
import com.moneytap.exceptions.WalletIdNotFoundException;
import com.moneytap.modal.BeneficieryDetails;
import com.moneytap.services.BeneficieryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/beneficiery")
public class BeneficieryController {

    @Autowired
    private BeneficieryService beneficieryService;
    @GetMapping("/")
    public List<BeneficieryDetails> getAllBenefecieries(){
        return beneficieryService.getAllBenefecieries();


    }
    @GetMapping("/{beneficieryId}")
    public BeneficieryDetails viewBenefecierayDetails(@PathVariable int beneficieryId) throws BenefecieryNotFoundException {
        return beneficieryService.viewBenefecierayDetails(beneficieryId);

    }
    @DeleteMapping("/{beneficieryId}")
    public  void deleteBenefecieraryDetails(@PathVariable int beneficieryId) throws BenefecieryNotFoundException {
        beneficieryService.deleteBenefecieraryDetails( beneficieryId);

    }
    @PostMapping("/addBeneficiery/{walletId}")
    public void addBenefecierary(@RequestBody BeneficieryDetails beneficieryDetails,@PathVariable int walletId) throws WalletIdNotFoundException {
        beneficieryService.addBenefecierary(beneficieryDetails,walletId);


    }
}
