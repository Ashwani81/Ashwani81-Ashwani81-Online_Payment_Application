package com.moneytap.services;

import com.moneytap.exceptions.BankAccountNotFoundException;
import com.moneytap.exceptions.WalletIdNotFoundException;
import com.moneytap.modal.BankAccount;

import java.util.List;

public interface BankAccountService {
    List<BankAccount> getAllAccounts();
    void addBankAccount(BankAccount bankAccount,int walletId) throws WalletIdNotFoundException;
    void removeAccount(int bankAccount) throws BankAccountNotFoundException;
}
