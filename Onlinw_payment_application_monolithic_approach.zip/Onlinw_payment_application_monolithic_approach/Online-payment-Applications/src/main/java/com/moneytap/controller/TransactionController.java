package com.moneytap.controller;

import com.moneytap.exceptions.ItemsNotFoundException;
import com.moneytap.modal.Transaction;
import com.moneytap.services.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;
@RestController
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @GetMapping("/allTransaction")
    public List<Transaction> viewAllTransactions(){
       return transactionService.viewAllTransactions();

    }
    @GetMapping("transactionByDate/{date}")
    public List<Transaction> viewTransactionByDate(@PathVariable  String date) throws ItemsNotFoundException {
        LocalDate localDate=LocalDate.parse(date);

        return transactionService.viewTransactionByDate(localDate);

    }
    @GetMapping("/translationByType/{type}")
    public List<Transaction> viewTransactionByType(@PathVariable String type) throws ItemsNotFoundException {
        return transactionService.viewTransactionByType(type);

    }
}
