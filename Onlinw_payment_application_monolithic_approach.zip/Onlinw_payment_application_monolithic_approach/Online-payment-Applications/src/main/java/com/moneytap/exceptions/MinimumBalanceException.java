package com.moneytap.exceptions;

public class MinimumBalanceException extends Exception{
    public MinimumBalanceException(String msg){
        super(msg);
    }
}
