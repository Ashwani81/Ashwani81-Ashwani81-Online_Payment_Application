package com.moneytap.exceptions;

public class BenefecieryNotFoundException extends Exception{

    public BenefecieryNotFoundException(String msg){
        super(msg);
    }
}
